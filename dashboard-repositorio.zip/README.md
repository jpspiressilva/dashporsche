# Dashboard de Vendas de Carros

## Publicação no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie os arquivos deste diretório.
3. Vá em Settings > Pages.
4. Selecione Deploy from a branch.
5. Escolha branch main e pasta /root.
6. Salve.

O dashboard ficará disponível por uma URL pública do GitHub Pages.
